# Software Requirements Specification (SRS)
## Sports Field Booking Platform — Phase 1

**Document status:** Living document — update as scope changes.
**Version:** 1.22
**Date:** August 16, 2026
**Based on:** product-brief.md v1.8, Phase 1 discovery session

**v1.1 revisions:** Hosting changed from Railway to a self-managed VPS; notifications changed from SMS to email (SMS retained for OTP only); added the Field Configuration entity (shared, cascading templates for pricing/payment/refund policy); added manual booking entry for external-source reservations; added a public marketing landing page; added the Section 2.7 subscription pricing model.

**v1.2 revisions:** Confirmed the subscription tier metric (Section 2.7): billing is based on total app-sourced bookings per month, not unique players; manually entered bookings are excluded from the tier count.

**v1.3 revisions:** Club owner authentication changed from SMS OTP to Google Sign-In (recommended option) plus email/password credentials; SMS and the SMS gateway are removed from the system entirely (Sections 2.2, 2.6, 3.1, 4.3, 4.4, 5.3, 6.1, 7.2). Fixed the Section 4.1.2 leftover reference to a "confirmation SMS" (all player communication is email). Roadmap confirmed against brief v1.4: Phase 2 is automatic payments via gateway; Phase 3 is the full native client app (Flutter) with cross-court discovery.

**v1.4 revisions:** Player authentication added to the public booking link: players sign in with Google (recommended) or email/password, using deferred login (browsing availability and prices requires no account; authentication is requested only at the moment of booking or cancellation). Player sessions persist for a configurable period (default 30 days) so returning players are not re-prompted. Revised: FR-AUTH-3 to FR-AUTH-9, FR-BOOK-4, FR-NOT-5, FR-CAN-2, Sections 2.2, 2.3, 2.6, 4.1.2, 4.3, 5.3, 5.4, 6.1, 7.2. Manual bookings entered by owners are unchanged and never require a player account.

**v1.5 revisions:** Internal admin panel descoped: the cross-field bookings overview and booking support view are removed. The panel now focuses on club account management and manual recording of subscription payments (owners pay the platform outside the system). Added tier-based payment verification reminders: when an owner's monthly app-sourced booking count reaches their tier limit, the panel raises a reminder; if no covering payment is recorded within a configurable grace period (default 7 days), the account is automatically suspended until payment is recorded. Revised: FR-ADM-1 to FR-ADM-6, Sections 2.2, 2.3, 2.7, 4.1.3, 6.1.

**v1.6 revisions:** Closed the tier metering methodology open question (Section 2.7, FR-ADM-4): only bookings with status Confirmed count toward the monthly tier limit; Pending, Cancelled, and Expired bookings never count. The count is a point-in-time trigger, not a live-recalculated balance — a booking that is cancelled after its reminder has already fired does not retract that reminder or reduce the count.

**v1.7 revisions:** Clarified blackout period behavior against existing bookings (Section 3.2). Creating a blackout period is blocked if any slot in the target range has a Pending or Confirmed booking; the owner must cancel the conflicting booking(s) first (triggering FR-CAN-3/4/5) before the blackout can be created. Added FR-CAL-16.

**v1.8 revisions:** Corrected the document header and Section 1.4 to cite Product Brief v1.5 instead of v1.4. The player-authentication content introduced in this SRS's own v1.4 revision (deferred login, Google Sign-In/email-password for players, ~30-day sessions) operationalizes what the brief added in its v1.5, not v1.4; the citation was one version behind its own content. No functional requirements changed.

**v1.9 revisions:** Replaced the subscription model (Section 2.7) with three data-driven tiers (Free/Growth/Unlimited, monthly or annual at 10% off), stored in a `subscription_plan` table so the team can adjust them without a deployment. The public booking link is now never interrupted for any reason; instead, quota-exceeded or payment-overdue conditions restrict only the owner's own admin-panel access, with a non-blocking warning before the quota. Revised §2.7, FR-ADM-1 to FR-ADM-10 (expanded from the old FR-ADM-1 to 6), §4.1.3, §6.1; owner status "suspended" renamed to "restricted".

**v1.10 revisions:** Resolved the standing FR-PAY-2 / FR-CAN-1 ambiguity: both are reworded from "per field" to "per Field Configuration" (FR-CAL-10), matching what FR-CAL-12/13 and the schema already implemented — payment methods and refund policy are shared across every field referencing a configuration, not independently settable per field, unless the field is detached via FR-CAL-14. Also confirmed the Growth-tier warning threshold at 400 bookings (80% of its 500 quota, by analogy to Free's confirmed 80-of-100), replacing the prior placeholder assumption. Revised: FR-PAY-2, FR-CAN-1, Section 2.7, Section 4.1.1 (Settings).

**v1.11 revisions:** Fixed a leftover reference to the retired "Enterprise" tier name in Section 4.1.4 (landing page CTA), missed during the v1.9 subscription model rewrite. Note: the old Enterprise tier's "custom attention" perk (bespoke automation such as WhatsApp-based booking intake, built per customer) was not carried forward into the Unlimited tier definition in v1.9 and has not been reinstated — open question for the team on whether that perk still applies to Unlimited or was intentionally dropped.

**v1.12 revisions:** Removed booking-level pending/expiration — all bookings confirm at creation (owners verify payments, never bookings); statuses reduced to Confirmed/Cancelled (booking) and Available/Booked/Blackout (slot). Added Zelle and on-site VES/USD tender per payment; added the Booking Usage Period counter for point-in-time metering; split account restrictions to one row per reason; linked subscription payments to their subscription; aligned §6.1 with the ERD; added FR-CAL-17 (60-day slot horizon); dropped the Enterprise custom-attention perk. Revised FR-BOOK-7/9/12, FR-PAY-3/5/7/8, FR-ADM-4, FR-NOT-1/2, FR-CAL-16, §2.7, §4.1.1-4.1.3, §6.1, §7.2.

**v1.13 revisions:** Added manual refund recording (Refund entity, FR-CAN-6): the owner registers a refund against a confirmed payment with amount, date, and optional note. The refund policy (FR-CAN-1) is now advisory only — a non-binding eligibility hint (FR-CAN-4) that never blocks or forces a refund; the owner always decides (FR-CAN-5).

**v1.14 revisions:** Subscription payments are now collected in-platform, mirroring the player-to-owner flow: the owner sees the platform's Pago Móvil details and the VES amount, submits a reference, and the platform verifies it (FR-ADM-3, FR-ADM-11 to FR-ADM-13; platform_bank_account entity). Also renamed booking status Confirmed to Active; made the booking link per-club listing all fields (FR-BOOK-1); added optional Google Maps field location beside photos (FR-BOOK-3); capture player name/phone at signup, editable via the booking confirmation screen (FR-AUTH-10, FR-BOOK-4); allowed payments on manual bookings (FR-BOOK-13); let players view and cancel active bookings from the link (FR-CAN-2); set Resend as the email provider; and rewrote Section 6.1 as natural-language entity descriptions with the ERD as the source of truth.

**v1.15 revisions:** Corrected the Product Brief citation to v1.6 (header, §1.4, §8), reworded FR-ONB-3 to the per-club booking link (FR-BOOK-1), specified that a manual booking links to an existing player by matching email and otherwise falls back to the contact snapshot (§6.1, FR-BOOK-13), and gave the Free plan a rolling monthly metering period so quota metering is uniform across plans (§2.7, §6.1, FR-ADM-10). Schema-side (playspot-schema.mermaid): relationship cardinalities now match nullable FKs, the active-subscription and open-restriction partial unique indexes are documented, and the redundant booking.payment_status column was removed (payment status is now derived from the booking's payments).

**v1.16 revisions:** Split the single club account into a Club (the company behind the fields, holding the logo, booking link, subscription, and fields) and its Users, who join the Club through Memberships carrying a configurable Role. Added the Organization and Access Control module (new §3.11, ORG): the account creator is the founding Administrator, invites users by email (Google or password link), and defines roles that grant per-module admin-panel access. Also gave the Club a single logo and Fields multiple photos, and rewired owner_id to club_id across §6.1 and the schema.

**v1.17 revisions:** Renamed the tenant entity Business to Club and the role term field owner to club owner across the SRS and schema. Reworked FR-AUTH-6 so repeated failed password attempts block password login until a reset clears it (Google still works, per-IP throttle stays temporary, holder emailed on block; added failed_password_attempts and password_blocked_at to User and Player). Added duration-based pricing (FR-CAL-19, config_duration_price) with an explicit resolution precedence, and a public club directory (FR-BOOK-14, shown when no club is specified) that lists only platform-listed Clubs via a new admin-only listed flag (FR-ADM-14), with untrusted-URL/SSRF handling (NFR-SEC-6). Also revised FR-CAL-10, FR-CAL-15, and §4.1.1 to §4.1.4.

**v1.18 revisions:** Set the public-app routing to subdomains: the public booking app on the app subdomain (its root is the club directory, FR-BOOK-14), the club owner dashboard on the club subdomain, and the marketing page at www.domain.com/home (root redirects to /home). Implemented variable-duration booking by composition on the base-slot grid: a Booking now covers one or more contiguous base slots via a new booking_slot join (moving the one-active-booking-per-slot invariant there), and a configuration is flat or variable by how many duration entries it has (FR-BOOK-15). Revised FR-CAL-3/10/19, FR-BOOK-4/8, §4.1.1, §4.1.2, §6.1.

**v1.19 revisions:** Moved the base slot duration back from the Field Configuration to the availability rule (default 90 minutes): different rules on the same field, or on fields sharing a configuration, can now run different cadences (e.g., 60-minute weekday mornings, 90-minute weekend evenings), which per-config uniformity ruled out. Duration-price entries (FR-CAL-19) are consequently validated against whichever rule generates slots at the requested start time, rather than against one config-wide base; this is an app-level check, not DB-enforceable, since a config's fields/rules no longer share a single base. Revised FR-CAL-3/10/19, FR-BOOK-15, §4.1.1, §6.1.

**v1.20 revisions:** Reversed the "booking link is never restricted" rule — an open restriction now also pauses new bookings on the link (FR-BOOK-16), because a club locked out of the admin panel cannot verify the payments those bookings generate; existing bookings stay viewable and cancellable. Replaced the multiple-of-base duration test with a direct tiling-run walk over the slot grid (FR-CAL-19, FR-BOOK-15). Anchored quota metering to the club rather than the subscription period (FR-ADM-4), so plan changes no longer reset the counter, and made a new metering period resolve an open quota restriction (FR-ADM-6). Added the frozen booking total price (FR-BOOK-17), non-overlapping availability rules (FR-CAL-20), blackout deletion (FR-CAL-21), and a slot-deletion guard (FR-CAL-4). Cascaded club_id/field_id/total_price onto Booking and made player email required in the ERD.

**v1.21 revisions:** Made concurrency an explicit requirement rather than an assumption, now that a booking reserves several slots instead of one. Added §5.7 (Data Integrity and Concurrency, NFR-INTEG-1 to NFR-INTEG-5) requiring atomic validate-and-reserve, mutual exclusion between booking and calendar edits, and database-level enforcement of the stated invariants; added FR-BOOK-18 for what the player sees when a concurrent booking wins the race; strengthened FR-CAL-7 to a database-enforced non-overlap constraint. Revised NFR-PERF-2, §4.1.1, §4.1.2.

**v1.22 revisions:** Added FR-PAY-11 (a Club-level VES rate basis — USD by default or EUR — letting owners convert USD prices to VES at the VES-per-EUR rate, the common Venezuelan hedge against the official/market rate gap; it raises only the VES amount owed, never the USD price) and FR-ANA-6 (a settlement breakdown that separates hard-currency USD tender from VES intake and splits VES by USD/EUR basis, for reconciliation; USD-normalized revenue stays basis-independent, so the EUR premium appears only in the bolívar figures). Reworded FR-PAY-7/8/9/10, FR-ANA-2, and FR-BOOK-6; touched §1.3, §2.5/§7.1 (currency clause), §4.1.1/4.1.2, and §6.3. Generalized the ERD `exchange_rate` to (base_currency, rate_ves_per_unit), added `club.ves_rate_basis`, and froze `payment.rate_base_currency` so each payment's rate is fully self-describing without a join.

---

# 1. Introduction

## 1.1 Purpose

This SRS defines the functional and non-functional requirements for Phase 1 of the sports field booking platform. It translates the product brief into requirements precise enough to guide implementation (backend, admin panel, public booking link), to serve as a reference for UI mockups, and to be decomposed into OpenSpec specs and Linear/GitHub issues.

## 1.2 Scope

The system enables club owners in Venezuela (soccer and padel fields, extensible to other sports) to manage their own booking calendar through a web admin panel, and to accept bookings from players through a public, per-club web booking link that lists all of the owner's fields — without requiring players to install an app. Payment in Phase 1 is manual: Pago Móvil (VES), Zelle (USD), or Pay On Site, confirmed by the club owner. Given Venezuela's high inflation, club owners set prices in USD, and any VES payment is recorded together with the VES amount and the USD-equivalent exchange rate in effect at the moment of payment. Automated payment gateway integration is out of scope for Phase 1 (targeted for Phase 2). A native client app (Flutter) with cross-field discovery is out of scope for Phase 1 (targeted for Phase 3).

## 1.3 Definitions, Acronyms, and Abbreviations

| Term | Definition |
|---|---|
| Club | The company behind one or more sports fields (the tenant/account). Holds the display name, logo, public booking link, subscription, fields, and its team of users. Spanish UI label: "Club". Formerly modeled as a single "club owner" account. |
| Club owner | Legacy synonym, kept for readability, for a Club and, informally, for a Club user who manages it. The account model is Club + Users + Roles (see §3.11). |
| Club user (member) | A person with a login who belongs to a Club through a Membership and a Role. The account creator is the founding Administrator. |
| Role | A named, configurable set of admin-panel module permissions within a Club (e.g., Administrador, Recepción), created and edited by an Administrator (§3.11). |
| Module | A grantable unit of admin-panel functionality (calendar, bookings, payments, fields, field configurations, analytics, settings, billing, user management) that a Role may allow or deny. |
| Invitation | A pending, tokenized email invite for a person to join a Club with an assigned Role, accepted by setting a password or signing in with Google. |
| Player | The end user who books a field through the public booking link. |
| Booking link | A public, per-club URL listing the owner's fields, where players view availability and create a booking. |
| Slot (base slot) | The smallest bookable time interval on a field's grid (e.g., 8:00–9:30 AM), generated by an availability rule at that rule's own base duration, or created manually. A booking covers one or more contiguous base slots. |
| Tiling run | The contiguous sequence of Available base slots that a booking of a requested duration must cover exactly: it starts precisely at the chosen start time, has no gaps between consecutive slots, and sums to exactly the requested duration — no overshoot (FR-CAL-19). |
| Flat / variable configuration | A Field Configuration with zero or one duration-price entry is *flat*: the player gets no duration choice. With two or more entries it is *variable*: the player picks a duration at booking time (FR-CAL-19, FR-BOOK-15). |
| Club slug | The unique, URL-safe identifier of a Club, carried as a path segment in its booking link (`app.domain.com/reservar/{club_slug}`, FR-BOOK-14). |
| Metering period | The rolling monthly window over which a Club's app-sourced booking quota is counted. Anchored to the Club itself (not to its subscription or billing cycle), so plan changes and annual billing never reset the counter (FR-ADM-4). |
| Blackout date | A date/time range marked unavailable by the club owner (e.g., maintenance). |
| Reference number flow | Manual payment confirmation flow: player submits a Pago Móvil reference number, owner verifies and confirms. |
| Google Sign-In | OAuth 2.0 / OpenID Connect authentication using the user's Google account, offered as the recommended sign-in method for both club owners and players. |
| Deferred login | Booking-link pattern where public content (availability, prices) requires no authentication, and sign-in is requested only when the player attempts an action that requires an account (booking, cancellation). |
| Reference exchange rate | The VES-per-unit rate used to convert a USD field price into the VES amount expected for a given payment, captured at the time of that payment. Its base currency is USD by default, or EUR where the Club has selected the EUR basis (VES rate basis, FR-PAY-11); the value and base currency are both frozen on the payment. |
| VES rate basis | A Club-level setting choosing which currency's BCV rate converts a USD price into the VES amount owed on a VES-settled payment: USD (default, VES = USD price × VES-per-USD) or EUR (VES = USD price × VES-per-EUR). EUR is never a tender — only a conversion basis that raises the bolívares owed while leaving the USD price unchanged (FR-PAY-11). |
| Field Configuration | A reusable template (sport type, default pricing, accepted payment methods, refund policy) that one or more fields can reference; editing it updates every field that references it. |
| SRS | Software Requirements Specification (this document). |

## 1.4 References

- Product Brief — product-brief.md, v1.8
- Phase 1 discovery session (clarifying questions and answers), July 2026

## 1.5 Overview

Section 2 gives an overall description of the product. Section 3 lists functional requirements grouped by module. Section 4 defines interface requirements, including screen-level detail intended to guide UI design. Section 5 defines non-functional requirements. Section 6 outlines data requirements. Section 7 lists constraints and assumptions.

---

# 2. Overall Description

## 2.1 Product Perspective

The platform is a new, standalone system replacing manual processes (WhatsApp, phone calls, paper) that club owners currently use to manage bookings. It is a two-sided marketplace, but Phase 1 intentionally serves only one side directly (club owners); players are reached indirectly through links that owners share themselves. Architecture: Angular front ends (admin panel and booking link), a Spring Boot REST API, and a PostgreSQL database, self-hosted on a VPS.

## 2.2 Product Functions (Summary)

- Organization accounts: each account is a Club (the company behind the fields) with a single logo, its own booking link and subscription, that can hold multiple users
- Team management with configurable roles: the founding Administrator invites users by email (Google or password link) and defines roles granting per-module admin-panel access
- Club logo and multiple photos per field, shown on the public booking link
- Club owner authentication via Google Sign-In (recommended) or email/password
- Player authentication on the booking link via Google Sign-In (recommended) or email/password, requested only at booking time (deferred login)
- Management of one or more fields per owner
- Calendar management: recurring slots, manual slots, blackout dates, per-slot pricing
- Public, per-club booking link listing all the owner's fields, for players
- Public club directory at the booking app root, listing platform-approved Clubs (FR-BOOK-14)
- Manual payment confirmation (Pago Móvil, Zelle, Pay On Site)
- Email notifications (booking confirmation, cancellation)
- Booking cancellation with configurable refund policy
- Basic analytics dashboard (bookings, revenue, occupancy)
- CSV and PDF data export
- Internal admin panel (club account management, verification of owner-submitted subscription payments, configurable subscription plans, quota/payment-based account restrictions that pause both the admin panel and new bookings on the link)
- Assisted club onboarding
- Shared Field Configurations (pricing, payment methods, refund policy) reusable across multiple fields
- Manual booking entry for reservations from external sources (WhatsApp, phone, walk-in)
- Public marketing landing page (product overview, pricing tiers, contact)

## 2.3 User Classes and Characteristics

| User class | Description | Technical proficiency |
|---|---|---|
| Club Administrator | Founding or promoted user of a Club (the primary customer in Phase 1). Full admin-panel access; manages fields, calendar, pricing, payments, billing, and the Club's own users and roles. Currently uses WhatsApp/phone/paper. | Low to medium |
| Club staff | An invited user of a Club whose role grants a subset of admin-panel modules (e.g., a receptionist limited to calendar, bookings, and payments). | Low to medium |
| Player | Accesses only the public booking link shared by a specific club owner. Browses availability without an account; creates a lightweight account (Google or email/password) at the moment of first booking. No app required in Phase 1. | Low |
| Internal admin (platform team) | Manages club accounts and subscription plans, verifies owner-submitted subscription payments, and monitors quota/payment-based account restrictions. | High |

## 2.4 Operating Environment

- Admin panel: modern web browsers (Chrome, Safari, Edge), desktop-first, responsive.
- Booking link: mobile-responsive web page, optimized for mobile browsers (majority of player traffic expected on mobile).
- Backend: Spring Boot application deployed on a self-managed VPS (Linux server).
- Database: PostgreSQL, self-hosted on the same or a dedicated VPS.

## 2.5 Design and Implementation Constraints

- UI language: Spanish only in Phase 1.
- Currency: VES and USD only, no multi-currency abstraction beyond these two. (EUR appears solely as an optional rate basis for computing VES amounts — FR-PAY-11 — and is never tendered, priced in, or stored as a payment currency.)
- No payment gateway integration in Phase 1 — manual confirmation only.
- No native mobile app in Phase 1 — web-only.
- Stack fixed: Angular, Spring Boot, PostgreSQL, self-managed VPS.

## 2.6 Assumptions and Dependencies

- Club owners have an email address; most have a Google account (Android is the dominant mobile platform in Venezuela), making Google Sign-In viable as the primary authentication method.
- Club owners are willing to manually verify Pago Móvil/Zelle payments before confirming bookings.
- Players trust a link shared by a club owner enough to book through it, and are willing to sign in with Google (or create an email/password account) at booking time; most players have a Google account (Android is the dominant mobile platform in Venezuela).

## 2.7 Subscription Pricing Model

The platform is monetized through a subscription charged to club owners, in three tiers. Plan definitions (name, price, booking quota, warning threshold) are stored as configurable data (`subscription_plan`, see Section 6.1), not hardcoded, so the platform team can rename a plan, adjust a quota, or change pricing without a code deployment. The values below are the tiers as currently configured, for reference:

| Tier | Monthly price | Annual price (10% off 12×monthly) | App-sourced bookings/month | Warning threshold |
|---|---|---|---|---|
| **Free** | $0 | n/a (no annual option) | 0–100 | 80 |
| **Growth** | $100/month | $1,080/year | 101–500 | 400 |
| **Unlimited** | $200/month | $2,160/year | Unlimited | n/a |

*Metering definition: the billable unit is total bookings that reach status Active per **metering period** made through the public booking link (FR-BOOK-1 to FR-BOOK-8), counted per booking, not per unique player — e.g., 100 Active bookings by a single player still count as 100. The count is a point-in-time, monotonic counter: it increments the moment a booking becomes Active and is NEVER decremented within its period. A booking cancelled after being counted remains counted; all link bookings are Active at creation (FR-BOOK-7). Manually entered bookings (FR-BOOK-10 to FR-BOOK-13, source = WhatsApp/Phone/Walk-in/Other) do NOT count toward any plan's quota, since they did not originate from the app. See FR-ADM-4 and Section 7.2.*

*Metering period vs. billing period: the metering period is a rolling monthly window anchored to the Club (its creation day-of-month), deliberately independent of the subscription and its billing cycle. Keeping the two separate serves two purposes: an annual subscriber still meters monthly rather than accumulating a year's bookings against a monthly quota, and changing plans mid-period does not open a fresh period and hand the owner a free quota reset. A plan change takes effect immediately for **which** quota applies; it does not reset **how many** bookings have been counted (FR-ADM-4).*

*Billing cycle: a subscription to Growth or Unlimited may be billed monthly or annually (owner's choice); Free has no billing cycle since nothing is charged. Quota metering does not depend on the billing cycle at all — every Club, on every plan, meters on its own rolling monthly period (above). Annual billing is discounted 10% versus paying monthly twelve times. Collection is manual in Phase 1 but flows through the platform, mirroring the player-to-owner payment process: when a payment is due, the owner is shown the platform's Pago Móvil details and the amount owed converted to VES at the current reference rate (FR-ADM-11, FR-ADM-12), pays by transfer, and submits the reference number; the platform team then verifies that reference and confirms the payment in the internal admin panel (FR-ADM-13). Submitting a reference emails both the owner and the platform team. There is no automatic charging or payment gateway.*

**Enforcement.** Two independent conditions can place an open **restriction** on a Club:

1. **Quota exceeded.** The Club's app-sourced Active-booking count for the current metering period reaches their plan's quota (100 for Free, 500 for Growth) without having upgraded. Restriction is immediate — there is no grace period for this condition, since it isn't a payment failure. It is lifted by upgrading to a plan with sufficient quota, or automatically when the next metering period opens and the counter resets (FR-ADM-6, FR-ADM-8).
2. **Payment overdue.** For a paid plan (Growth or Unlimited), no subscription payment covering the current billing period is recorded within a configurable grace period (default 7 days) after the period's due date. Recording the covering payment lifts it automatically (FR-ADM-7, FR-ADM-8).

While any restriction is open, two things are paused:

- **Admin-panel access** is limited to the plan/billing screen, which stays reachable so the owner can resolve the restriction (FR-ADM-6, FR-ADM-7).
- **New bookings on the public booking link** are refused for every field of that Club, and the Club is withheld from the public directory (FR-BOOK-16).

*Rationale for pausing the link.* Earlier versions of this document held the booking link inviolable, on the grounds that interrupting it cuts off the club's revenue. That reasoning does not survive contact with the payment flow: an owner locked out of the admin panel cannot verify a single Pago Móvil or Zelle reference (FR-PAY-3). Leaving the link open would therefore keep taking players' money into a queue nobody can process — players pay for reservations that are never confirmed, and the club accrues a verification backlog it is barred from clearing. Refusing the booking outright is the less damaging failure: no money moves, and nothing has to be unwound. The pause is deliberately scoped to *creating* bookings; players who already hold an Active booking can still view and cancel it (FR-CAN-2), since cancellation neither collects money nor requires the owner to act.

*What the player sees.* The unavailable state never discloses the Club's billing or quota situation — that is the platform's business relationship with the Club, not the player's. The message states only that the Club is not accepting online bookings at the moment and surfaces the Club's contact details so the player can reach it directly (FR-BOOK-16).

A configurable, non-blocking **warning notification** fires before the quota is reached (confirmed thresholds: 80 on Free, 400 on Growth; Unlimited has no quota so no threshold applies), giving the owner advance notice to upgrade before they're restricted (FR-ADM-5). Combined with the 7-day grace period on the payment-overdue side, no Club reaches a paused link without prior notice.

If both conditions apply at once (over quota *and* unpaid), the account remains restricted until both are resolved; the platform team sees both reasons in the internal panel (FR-ADM-1, FR-ADM-8).

---

# 3. Functional Requirements

Each requirement has a unique ID, a description using "shall," and an implicit priority (all listed requirements are Phase 1 / must-have unless marked otherwise).

## 3.1 Authentication (AUTH)

- **FR-AUTH-1** The system shall authenticate Club users (owner-side) using either Google Sign-In (OAuth 2.0 / OpenID Connect) or an email address and password. A Club user's access to a given Club is governed by their Membership and Role (§3.11).
- **FR-AUTH-2** The login and onboarding screens shall present Google Sign-In as the recommended, visually primary option, with email/password offered as the alternative.
- **FR-AUTH-3** The system shall store all passwords (club owner and player accounts) only as salted hashes using a modern algorithm (bcrypt or Argon2); plaintext passwords shall never be stored or logged.
- **FR-AUTH-4** The system shall provide a password reset flow via a time-limited, single-use link sent to the account's registered email address, for both club owners and players.
- **FR-AUTH-5** The system shall authenticate players on the public booking link using either Google Sign-In (presented as the recommended, visually primary option) or an email address and password, following the deferred login pattern: viewing the booking link, availability, and prices shall NOT require authentication; sign-in shall be requested only when the player attempts to create or cancel a booking.
- **FR-AUTH-6** The system shall block password-based login for an account (Club user or Player) after a configurable number of consecutive failed password attempts (default: 5), and shall keep it blocked until the account holder completes the password reset flow (FR-AUTH-4) and sets a new password; a fixed cooldown is not sufficient, since it does not stop a sustained automated attempt. When an account becomes blocked, the system shall email the account holder that repeated failed logins blocked password sign-in and that a password reset is required to restore it, alerting a legitimate user to the attempts and giving them the recovery path. A blocked account may still sign in via Google Sign-In if linked to the account, since that credential is not exposed by password guessing. Independently of the per-account block, the system shall apply a temporary, short-cooldown rate limit per source IP address (regardless of which account is targeted) to slow distributed or credential-stuffing attempts; the per-IP limit remains temporary rather than a hard block, since IP addresses are frequently shared or dynamic.
- **FR-AUTH-7** The system shall treat the email address as the unique account identifier within each user class: if a user registered with email/password later signs in with Google using the same email (or vice versa), the system shall resolve both methods to the same account rather than creating a duplicate. Consequently, an account is not tied to a single provider: it stores an optional Google subject identifier (google_subject_id) and an optional password hash, and both may coexist on the same account, either being sufficient to sign in. Club-user accounts, player accounts, and platform-admin accounts are separate account spaces; the same email may exist once in each. A Club user is a single global identity that may belong to more than one Club through Memberships (§3.11); email uniqueness is enforced across all Club users, not per Club.
- **FR-AUTH-8** The system shall NOT use SMS, WhatsApp, or OTP codes for authentication or any other purpose in Phase 1.
- **FR-AUTH-9** Player sessions on the booking link shall persist across visits for a configurable period (default: 30 days), so a returning player is not asked for credentials again within that window; signing out or an expired session returns the player to the deferred login behavior of FR-AUTH-5.
- **FR-AUTH-10** Immediately after a player account is created (via Google or email/password), the system shall prompt for the player's name and phone number and store them on the player profile. Neither is verified. For Google sign-ups the name is prefilled from the Google account and remains editable. These details are captured at account creation (which happens at first booking, per deferred login) and are editable thereafter via the booking confirmation screen (FR-BOOK-4); Phase 1 has no separate player profile-management module.

## 3.2 Field and Calendar Management (CAL)

- **FR-CAL-1** The system shall allow a club owner to register and manage more than one field under a single account.
- **FR-CAL-2** The system shall allow a club owner to define a sport type at the Field Configuration level (see FR-CAL-10), selecting from at least soccer and padel, with the data model extensible to additional sports (e.g., tennis) without a schema change.
- **FR-CAL-3** The system shall allow a club owner to create recurring availability rules defining days, a daily time window, and the base slot duration for that rule (e.g., "Monday–Friday, 8:00 AM–10:00 PM, 90-minute slots"; default 90 minutes). The rule generates base slots of its own duration across its window; different rules on the same field (or on fields sharing a Field Configuration) may use different base durations (e.g., 60-minute weekday mornings and 90-minute weekend evenings).
- **FR-CAL-4** The system shall allow a club owner to manually create, edit, or delete individual slots. A slot covered by an active booking (via booking_slot, FR-BOOK-8) shall not be deleted, nor have its start or end time changed; the system shall refuse the operation and show the conflicting booking, which the owner must cancel first (FR-CAN-3). Editing the price of a booked slot is separately barred by FR-CAL-9, and in any case would not alter the booking's frozen total (FR-BOOK-17).
- **FR-CAL-5** The system shall allow a club owner to mark a date range as a blackout period, making all slots within it unavailable for booking. Existing Available slots within the range shall transition to Blackout status; future slots generated within the range (FR-CAL-3) shall be created directly as Blackout.
- **FR-CAL-6** The system shall present the calendar in a drag-and-drop interactive view for creating and adjusting slots.
- **FR-CAL-7** The system shall prevent the existence of two overlapping slots for the same field, whether generated by an availability rule (FR-CAL-3) or created manually (FR-CAL-4). This shall be enforced by the database as a constraint on the slot table, not by application checks alone (NFR-INTEG-3): a slot's field and time range together must be non-overlapping. Beyond preventing a corrupt calendar, this guarantees that at most one slot exists at any instant on a field, which is what makes the tiling walk of FR-CAL-19 deterministic — without it, a run starting at a given time could have more than one candidate slot and no defined answer.
- **FR-CAL-8** The system shall allow a club owner to set pricing on a Field Configuration: a base price plus optional time-of-day rate bands (e.g., morning/afternoon/night). Bands are defined once on the configuration and shared by every field referencing it. Slots inherit the applicable band's price at generation and remain individually editable per FR-CAL-9.
- **FR-CAL-9** The system shall allow a club owner to edit the price of a slot that has not yet been booked.
- **FR-CAL-10** The system shall allow a club owner to define reusable Field Configurations, each specifying: sport type, default pricing (base price, optional time-of-day rate bands (FR-CAL-8), and optional duration-based prices (FR-CAL-19)), accepted payment methods, and refund policy. The base slot duration is not set on the configuration; it is set per availability rule (FR-CAL-3), since different rules — even on the same field — may run different cadences.
- **FR-CAL-11** The system shall allow a club owner to assign an existing Field Configuration to a new or existing field, or to create a new Field Configuration during field setup.
- **FR-CAL-12** The system shall allow multiple fields to reference the same Field Configuration (e.g., two identical padel fields), while allowing each field to remain distinct in its own name, photo, calendar, and bookings.
- **FR-CAL-13** When a club owner edits a Field Configuration, the system shall apply the change to all fields currently referencing that configuration.
- **FR-CAL-14** The system shall allow a club owner to detach a field from a shared Field Configuration by creating an independent copy of that configuration for the field (e.g., a "Premium" variant), without affecting other fields still referencing the original.
- **FR-CAL-15** New base slots created for a field shall default to the pricing defined in that field's active Field Configuration, resolved as: the matching time-of-day rate band (FR-CAL-8) if one applies, otherwise the base price. Duration-based prices (FR-CAL-19) are deliberately *not* applied here — a duration price is the total for a whole booking, not a per-base-slot rate, and resolves only at booking time (FR-BOOK-15). Slot prices remain individually editable per FR-CAL-9.
- **FR-CAL-16** The system shall block the creation of a blackout period if any slot within the target date range has an active (Active, not Cancelled) booking; the owner shall be shown the conflicting booking(s) and must cancel them (FR-CAN-3) before the blackout period can be created.
- **FR-CAL-17** Recurring availability rules (FR-CAL-3) shall materialize slots on a rolling generation horizon: slots shall exist at least a configurable number of days ahead (default: 60), extended by a scheduled daily job. Slots beyond the horizon are not shown or bookable until generated. Generated slots falling inside a blackout period are created directly as Blackout (FR-CAL-5).
- **FR-CAL-18** The system shall allow a user with the fields module (§3.11) to attach multiple photos to a field, reorder them, remove them, and mark one as primary. The primary photo is the field's cover on the booking link; the full set is shown as a gallery (FR-BOOK-3). A field may have zero photos and remains fully bookable.
- **FR-CAL-19** The system shall allow a club owner to define duration-based pricing on a Field Configuration: a list of (duration, price) entries (e.g., 60 min = $20, 90 min = $30, 120 min = $38). A configuration with zero or one entry is flat (single booking length, no player duration choice); a configuration with two or more entries is variable, offering the player a choice of duration at booking (FR-BOOK-15).

  **Achievability — the tiling run.** A requested duration D is bookable at a given start time T if and only if, walking forward from T over that field's base slots, there exists a run satisfying all four conditions:
  1. the first slot's start time equals T exactly;
  2. each slot's end time equals the next slot's start time (no gaps);
  3. every slot in the run has status Available;
  4. the slots' durations sum to exactly D — the walk rejects on overshoot, never rounding up or leaving a partial slot.

  Slot provenance is irrelevant: a valid run may span slots generated by different availability rules or include manually created slots (FR-CAL-4), so long as it tiles the requested duration exactly. This replaces the earlier rule that D had to be a whole multiple of some single base duration, which could not be stated coherently once base duration moved to the availability rule (FR-CAL-3) and never covered manual slots at all. Because the test walks live slot state, which durations are offered varies by field, by time of day, and by what is already booked; it is evaluated at booking time and is not a constraint on the configuration itself.

  **Pricing precedence.** A booking of duration D is priced by resolving, in order: (1) the duration entry matching D, if defined; (2) the matching time-of-day rate band (FR-CAL-8) applied to the base price; (3) the base price. Where no duration entry applies and the run covers several base slots spanning different rate bands, the resolved prices of the covered base slots are summed. The resulting total is frozen onto the booking at creation (FR-BOOK-17). Individual base-slot prices remain editable while unbooked (FR-CAL-9).

- **FR-CAL-20** The system shall prevent two availability rules on the same field from overlapping. Two rules overlap when their day-of-week sets intersect, their daily time windows intersect, and their validity ranges (valid_from/valid_until) intersect; the system shall reject creating or editing a rule into such an overlap and shall identify the conflicting rule. This was previously implicit in FR-CAL-7 (no two overlapping slots per field), but FR-CAL-7 constrains generated slots after the fact — without a rule-level check, two overlapping rules with different base durations would simply fail slot generation, or silently produce a broken grid. Non-overlapping rules also guarantee that the tiling walk of FR-CAL-19 sees at most one candidate slot at any instant.
- **FR-CAL-21** The system shall allow a club owner to delete or shorten a blackout period. On deletion or shortening, every base slot that the removed range covered shall return to Available, except where another blackout period still covers it, in which case it remains Blackout. No slot in a blackout range can be booked (FR-CAL-16 blocks creating a blackout over active bookings, and blacked-out slots are not offered), so this transition never disturbs a booking.

## 3.3 Public Booking Link (BOOK)

- **FR-BOOK-1** The system shall generate a single unique, public, shareable URL per Club, of the form `app.domain.com/reservar/{club_slug}`. Opening it shall list all of that Club's active fields; selecting a field shall show that field's available slots and prices. A specific field may also be deep-linked directly within the Club's booking link (`.../{club_slug}/{field_slug}`).
- **FR-BOOK-2** The booking link page shall display the field's sport type, available slots, and pricing.
- **FR-BOOK-3** The booking link shall display the Club's logo on the club landing view (when set), and for each field its photos as a gallery (zero or more, with one marked primary as the cover) and, when the owner has set a location (latitude/longitude), an embedded Google Maps pin. Logo, photos, and location are all optional but strongly recommended; the booking link shall omit whichever is not set, and a field shall remain fully bookable with no logo, no photos, and no location.
- **FR-BOOK-4** The system shall allow a signed-in player (FR-AUTH-5) to select an available start time (and a duration where the field's configuration offers a choice, FR-BOOK-15) and submit a booking. Before finalizing, the system shall show a confirmation screen prefilled with the player's name and phone (FR-AUTH-10) that the player reviews and can edit; any edit is saved back to the player profile, so this screen also serves as the way a returning player updates their name or phone. Email is taken from the account. Browsing prior to sign-in shall show full availability and prices (deferred login).
- **FR-BOOK-5** The system shall allow the player to choose a payment method at booking time: Pago Móvil, Zelle, or Pay On Site.
- **FR-BOOK-6** If Pago Móvil or Zelle is chosen, the system shall display payment instructions and collect a payment reference number from the player. For Pago Móvil, the VES amount shown to the player shall be computed at the Club's configured VES rate basis (USD or EUR, FR-PAY-11); Zelle instructions show the USD amount unchanged.
- **FR-BOOK-7** The system shall mark every newly submitted booking as Active immediately at creation, for all sources. Club owners shall never be required to confirm, approve, or ratify a booking for it to hold its slot; the owner's only manual verification work is on payments (FR-PAY-3), whose lifecycle is independent of booking status. There is no pending state and no booking expiration; a booking is released only by cancellation (Section 3.6).
- **FR-BOOK-8** The system shall immediately remove booked base slots from availability shown to other players. A booking covers one or more contiguous base slots (FR-BOOK-15); invariant: a base slot's Booked status is equivalent to being covered by exactly one Active booking (via booking_slot; see Section 6.1, Slot).
- **FR-BOOK-9** *(Removed in v1.12 — bookings no longer expire; ID retained for traceability.)*
- **FR-BOOK-10** The system shall allow a club owner to manually create a booking directly from the admin panel's calendar, for reservations originating outside the public booking link (e.g., phone call, WhatsApp message, walk-in).
- **FR-BOOK-11** The system shall record a source for every booking (Booking link, WhatsApp, Phone, Walk-in, or Other) to distinguish self-service bookings from manually entered ones.
- **FR-BOOK-12** A manually created booking shall be Active immediately at creation, the same as any other booking (FR-BOOK-7).
- **FR-BOOK-13** For a manually created booking, the system shall allow the club owner to record the player's name and, optionally, phone number and email, and to register a payment for it using any accepted method — Pago Móvil or Zelle (with reference number) or Pay On Site — capturing the tender currency and amount as in FR-PAY-3. None of these fields shall be mandatory for a manual booking. When the owner supplies an email that matches an existing player account, the system shall link the booking to that player; if no email is given or none matches, the booking shall keep player null and rely on the recorded contact snapshot. The system shall not create a new player account for a manual booking.
- **FR-BOOK-14** When the public web app (served on the app subdomain, e.g., app.domain.com) is opened without a club identifier (the app root, or an unknown slug), the system shall show a public club directory. A shareable club booking link carries the club slug as a path segment on that subdomain (`app.domain.com/reservar/{club_slug}`), and a specific field deep-links as `app.domain.com/reservar/{club_slug}/{field_slug}` (FR-BOOK-1); an unknown slug returns to the directory. The directory shall list only Clubs that are active, flagged as listed (FR-ADM-14), and free of any open restriction (FR-BOOK-16), each linking to its own booking link. If a player is signed in with an active session and has active bookings, the directory shall also show those bookings with a cancel action (FR-CAN-2), regardless of the status of the Clubs those bookings belong to. If the directory would be empty, it shall show the PlaySpot logo and a brief empty-state message instead of an empty list. A Club's own booking link remains reachable directly by its slug whether or not the Club is listed; if the Club is restricted, that link resolves to the unavailable state of FR-BOOK-16 rather than to a booking flow.
- **FR-BOOK-15** When a field's Field Configuration is variable (two or more duration entries, FR-CAL-19), the booking flow shall let the player choose a duration at a selected start time, offering only those durations for which a valid tiling run exists at that start time (FR-CAL-19), each shown with its price. Choosing a duration reserves that entire run as a single booking, one booking_slot row per covered slot. When the configuration is flat, no duration choice is shown: with one duration entry the booking reserves the tiling run for that duration; with no entries it reserves the single base slot at the chosen start time. Manually created bookings (FR-BOOK-10) offer the club owner the same duration choice and are subject to the same tiling-run test. Cancelling a booking releases every base slot it covers.
- **FR-BOOK-16** While a Club has any open account restriction (FR-ADM-6, FR-ADM-7), the system shall refuse the creation of new bookings on that Club's public booking link, for every one of its fields and by any player. Opening the Club's link shall render an unavailable state that identifies the Club and shows its contact details (phone and notification email as configured), so the player can arrange a reservation directly, and shall state only that the Club is not currently accepting online bookings — it shall NOT disclose the restriction reason, the Club's plan, its quota, or its payment status, none of which are the player's concern. The Club is simultaneously withheld from the public directory (FR-BOOK-14). Bookings already Active are unaffected: the player may still view and cancel them (FR-CAN-2), and the owner may still cancel them from the admin panel once the restriction is lifted. Resolving every open restriction restores the link automatically, with no further action by the platform team.
- **FR-BOOK-17** The system shall persist the booking's total price in USD on the booking itself, computed by the precedence of FR-CAL-19 and frozen at the moment of creation. Subsequent edits to the Field Configuration's duration prices or rate bands, or to the price of any covered base slot, shall never alter the stored total of an existing booking. This total is the authoritative figure for the bookings list, the booking detail, revenue analytics (FR-ANA-2), and exports (FR-ANA-4, FR-ANA-5), and is recorded independently of whether any payment was ever registered — a Pay On Site booking cancelled before money changed hands still carries the price it was made at.

- **FR-BOOK-18** Where two players attempt to reserve overlapping slots at the same moment, the system shall allow exactly one to succeed and shall fail the other cleanly. The losing attempt shall be rejected at the availability step — before the player is asked for any payment method, payment reference, or contact confirmation — so that no player supplies payment information for a reservation that cannot be created. The player shall be shown a plain-language message stating that the time was taken while they were choosing, and shall be returned to a refreshed availability view for that field with their previous selection cleared, so the next attempt is made against current state. The system shall never present a partially reserved booking, a booking covering fewer slots than its duration requires, or a confirmation for a booking that did not succeed. The same behavior applies when the losing attempt is a club owner creating a manual booking (FR-BOOK-10).

## 3.4 Payments (PAY)

- **FR-PAY-1** The system shall support three Phase 1 payment methods: Pago Móvil (VES), Zelle (USD), and Pay On Site.
- **FR-PAY-2** The system shall allow the club owner to configure which payment methods are accepted per Field Configuration (FR-CAL-10); every field referencing that configuration accepts the same set of methods until the field is detached into an independent configuration copy (FR-CAL-14).
- **FR-PAY-3** The system shall allow the club owner to manually mark a pending payment as confirmed or rejected (Pago Móvil and Zelle reference-number verification), and to register a payment at the moment it is received — for both booking-link and manually created bookings (FR-BOOK-13) — recording the method, actual tender currency (VES or USD), amount, and reference number where applicable. Payment verification never affects the booking's Active status (FR-BOOK-7).
- **FR-PAY-4** The system shall NOT process any payment automatically or integrate with a payment gateway in Phase 1.
- **FR-PAY-5** The system shall record the actual tender currency (VES or USD) on each payment: Pago Móvil is always VES, Zelle is always USD, and Pay On Site may be either, chosen by the club owner when registering the payment (FR-PAY-3).
- **FR-PAY-6** The system shall treat USD as the reference currency for field pricing: club owners shall set slot prices in USD, given high VES inflation.
- **FR-PAY-7** For any payment settled in VES (Pago Móvil, or Pay On Site paid in VES), the system shall capture the reference exchange rate in effect at the moment the payment is registered — VES per USD by default, or VES per EUR where the Club has selected the EUR basis (FR-PAY-11) — and shall compute the expected VES amount as the USD price multiplied by that captured rate. Under the EUR basis the same numeric USD price yields more bolívares, because the VES-per-EUR rate is higher than the VES-per-USD rate; the USD price itself is unchanged.
- **FR-PAY-8** The system shall store, for every VES payment (regardless of method), both the VES amount paid and its USD-equivalent — where the USD-equivalent is the payment's USD price (the reference figure), **not** a value back-computed by dividing the VES amount by the VES-per-USD rate — together with the rate value used and its base currency (USD or EUR, FR-PAY-11). Under the EUR basis, dividing the collected VES by the VES-per-USD rate exceeds the USD price by design (that gap is the hedge); the stored USD-equivalent nonetheless remains the USD price, so revenue never inflates with the basis. All of these figures — VES amount, USD price, rate value, and base currency — shall be displayed together wherever the payment is shown (booking detail, bookings list, analytics, exports).
- **FR-PAY-9** The system shall retrieve the reference exchange rate(s) — VES per USD, and VES per EUR where any Club uses the EUR basis (FR-PAY-11) — from a configurable source (e.g., official BCV rate or a manually-set rate), and shall record which rate was used on each payment: its value and its base currency (USD or EUR). Historical payments thus remain traceable and reconstructable even if the rate source, the rates, or the Club's basis setting change later.
- **FR-PAY-10** The system shall allow the club owner to see, before confirming a Pago Móvil payment, the expected VES amount and the rate used (with its base currency, USD or EUR, FR-PAY-11), to compare against the reference number/amount reported by the player.
- **FR-PAY-11** The system shall let a club owner choose the currency basis used to convert a USD price into the VES amount owed on any VES-settled payment (Pago Móvil, or Pay On Site paid in VES): **USD** (default) — expected VES = USD price × the VES-per-USD reference rate — or **EUR** — expected VES = USD price × the VES-per-EUR reference rate. This is a single Club-level setting (a monetary convention of the business, not a per-field or per-configuration price), defaulting to USD; it is not settable per Field Configuration. The EUR basis reflects the common Venezuelan practice of quoting the same numeric price in euros for local-currency settlement, to offset the gap between the official and market exchange rates; it raises only the VES amount owed and never the USD price, which remains the reference figure for revenue, analytics, exports, and the booking's frozen total (FR-BOOK-17). Zelle (USD) and Pay On Site paid in USD are unaffected — no VES conversion occurs, so the basis is immaterial to them. The rate applied — its VES-per-unit value and its base currency (USD or EUR) — shall be frozen on the payment at payment time (FR-PAY-8), so the VES amount stays reconstructable if rates or the setting change later. This basis governs player→club booking payments only; platform→club subscription billing (FR-ADM-12) always converts at the VES-per-USD rate, regardless of the Club's basis setting.

## 3.5 Notifications (NOT)

- **FR-NOT-1** The system shall send an email notification to the club owner when a new booking is created, indicating its payment method and payment status so the owner knows whether a payment verification is pending.
- **FR-NOT-2** The system shall send an email notification to the player immediately when their booking is created (bookings are Active at creation, FR-BOOK-7), containing the booking confirmation, the booking reference (FR-CAN-2), and the payment status; and a follow-up email when the owner confirms or rejects the payment (Pago Móvil/Zelle).
- **FR-NOT-3** The system shall send an email notification to both parties when a booking is canceled.
- **FR-NOT-4** The system shall NOT provide in-app or in-platform messaging between owners and players in Phase 1.
- **FR-NOT-5** The system shall deliver notifications to the email address of each account: the club owner's account email and the player's account email (for Google sign-ins, the Google account email by default). For manually entered bookings without a player email, player-facing notifications are skipped. The system shall NOT use SMS for any purpose (per FR-AUTH-8).

## 3.6 Cancellations and Refunds (CAN)

- **FR-CAN-1** The system shall allow a club owner to define a cancellation/refund policy per Field Configuration (FR-CAL-10) (e.g., full refund if canceled 24+ hours in advance); every field referencing that configuration shares the same policy until the field is detached into an independent configuration copy (FR-CAL-14). The policy is advisory only (see FR-CAN-4): it drives the suggested-eligibility hint shown at cancellation and never blocks or forces an actual refund.
- **FR-CAN-2** The system shall let a signed-in player view and cancel their own bookings through the booking link: a returning signed-in player shall see a list of their active bookings on the link and can open any one to cancel it. The booking reference included in the confirmation email shall also deep-link directly to that booking's cancellation view (prompting sign-in first if the session has expired, per FR-AUTH-5).
- **FR-CAN-3** The system shall allow a club owner to cancel a booking from the admin panel.
- **FR-CAN-4** Upon cancellation the system shall compute a suggested refund eligibility from the field's configured policy (FR-CAN-1) and display it to the owner (and to the requester) as a non-binding hint. This is guidance only: it neither grants, blocks, nor forces a refund. The club owner always makes the final refund decision.
- **FR-CAN-5** Refund execution shall be manual: the club owner performs the actual money transfer outside the system and then registers the refund (FR-CAN-6). The owner may register a refund even when the policy suggests the booking is not eligible, and may decline to refund even when the policy suggests it is; the system shall never override the owner's decision.
- **FR-CAN-6** The system shall allow a club owner to register a refund against a specific confirmed payment, recording the amount refunded (USD), the date the transfer was made, and an optional note. A refund is always tied to a payment: a booking that never had a confirmed payment (e.g., a Pay On Site reservation cancelled before any money changed hands) has nothing to refund. At most one refund shall be recorded per payment: a partial refund is recorded as that single refund with a smaller amount than the payment, not as one of several instalments, and the owner shall not be able to register a second refund against a payment that already has one. The amount refunded shall not exceed the payment's USD amount. Registering a refund does not alter the booking's Cancelled status; it only records that money was returned. The existence of a refund record is the system's evidence that a refund occurred.

## 3.7 Analytics and Reporting (ANA)

- **FR-ANA-1** The system shall display, per club owner, the total number of bookings for the current month and historically.
- **FR-ANA-2** The system shall display total revenue for the current month and historically, broken down by payment method, normalized to USD (using each payment's recorded USD-equivalent, which is the reference USD price and is independent of the VES rate basis, FR-PAY-8/FR-PAY-11), with the underlying VES amounts available on drill-down and the tender/basis settlement breakdown given by FR-ANA-6.
- **FR-ANA-3** The system shall display an occupancy rate (booked slots vs. available slots) per field.
- **FR-ANA-4** The system shall allow the club owner to export bookings and revenue data as a CSV file.
- **FR-ANA-5** The system shall allow the club owner to export a monthly revenue report as a PDF.
- **FR-ANA-6** The system shall display, per Club and for the current month and historically, a **settlement breakdown** separating hard-currency intake from bolívar intake, so revenue can be reconciled against the account each payment actually landed in:
  - **(a) USD received** — the sum of `amount_usd` for USD-tender payments (Zelle and Pay On Site paid in USD), further breakable by method per FR-ANA-2;
  - **(b) VES received** ("bolívares recibidos") — the total `amount_ves` for VES-tender payments (Pago Móvil and Pay On Site paid in VES), split into two sub-figures: **VES at USD basis** and **VES at EUR basis** (FR-PAY-11), each summing the `amount_ves` of the VES payments settled at that basis, and together summing to total VES received.

  The USD-normalized revenue total (FR-ANA-2) is independent of the basis: a VES payment contributes its reference USD price whether it settled at the USD or the EUR basis, so the EUR premium appears only in the bolívar figures of (b) and never as additional USD revenue. Every figure in this breakdown is derivable from each payment's tender currency and its frozen rate value and base currency (FR-PAY-8, FR-PAY-11); no separate accounting ledger is maintained. The settlement breakdown shall be included in the CSV and PDF exports (FR-ANA-4, FR-ANA-5).

## 3.8 Internal Admin Panel (ADM)

- **FR-ADM-1** The system shall provide an internal panel, accessible only to the platform team, listing all club accounts with their stored status (active or deactivated), assigned subscription plan, billing cycle (monthly/annual), current metering-period app-sourced booking count, and the restriction reason(s) (quota exceeded, payment overdue, or both) where any restriction is open. "Restricted" shall be presented as a derived state — a Club is restricted exactly while it has at least one open Account Restriction row — and shall not be stored as a third value of the account status, so the two can never disagree.
- **FR-ADM-2** The system shall allow the platform team to create and deactivate club accounts.
- **FR-ADM-3** The system shall record subscription payments that club owners submit through the in-platform payment flow (FR-ADM-11 to FR-ADM-13): the platform team reviews the owner-submitted Pago Móvil reference and marks the payment confirmed or rejected. Each record captures the amount (USD and the VES paid), billing cycle, period covered, submitted reference, submission date, verification outcome, and an optional note. Confirming a payment that covers the current period clears any payment-overdue restriction (FR-ADM-7).
- **FR-ADM-4** The system shall track, per Club and metering period, the count of app-sourced bookings that reached status Active (public booking link only), to support the warning of FR-ADM-5 and the restriction of FR-ADM-6. This count shall be persisted as a monotonic counter (see Booking Usage Period, Section 6.1) incremented at the moment the booking becomes Active and never decremented within its period: a booking cancelled after being counted remains counted, and does not retract a warning or restriction already raised. The counter, not a live query over bookings, is the source of truth for quota evaluation. The metering period shall be a rolling monthly window anchored to the Club — its day-of-month anchor set at Club creation and clamped to at most the 28th — and shall be independent of the Club's subscription, plan, and billing cycle. Consequently: an annual subscriber meters monthly like everyone else; changing plans mid-period changes which quota applies but does not open a new period or reset the counter; and a Club on Free meters on exactly the same cadence as a paid Club.
- **FR-ADM-5** When a club owner's app-sourced booking count for the current metering period reaches their plan's configured warning threshold (default: 80 bookings on the Free plan; independently configurable per plan), the system shall send the owner a non-blocking email notification suggesting they consider upgrading before reaching their plan's quota. This notification does not restrict any access.
- **FR-ADM-6** When a club owner's app-sourced booking count for the current metering period reaches their plan's booking quota (100 for Free, 500 for Growth; Unlimited has no quota) without the owner having upgraded, the system shall immediately open a "quota exceeded" restriction: the owner's admin-panel access is limited to the plan/billing screen, and new bookings on the Club's public booking link are refused per FR-BOOK-16. There is no grace period for this condition. The restriction shall be lifted automatically by either of two events — the owner upgrading to a plan with sufficient quota, or the opening of the Club's next metering period (FR-ADM-4), whose counter starts at zero and therefore no longer exceeds the quota. The second path means a Club that exhausts a quota mid-period is paused only until that period rolls, rather than indefinitely; the system shall record which event resolved the restriction. Lifting the restriction restores both admin-panel access and the booking link, unless a payment-overdue restriction (FR-ADM-7) also remains open.
- **FR-ADM-7** For a club owner on a paid plan (Growth or Unlimited), if no subscription payment covering the current billing period is recorded within a configurable grace period (default: 7 days) after that period's due date, the system shall open a "payment overdue" restriction: the owner's admin-panel access is limited to the plan/billing screen, and new bookings on the Club's public booking link are refused per FR-BOOK-16. Confirming a payment that covers the period (FR-ADM-3, FR-ADM-13) shall lift this restriction automatically (unless a quota-exceeded restriction, FR-ADM-6, also applies).
- **FR-ADM-8** If both the FR-ADM-6 and FR-ADM-7 conditions apply to the same account simultaneously, the system shall keep the account restricted, and shall display both reasons, until both are individually resolved (upgrade recorded and covering payment recorded).
- **FR-ADM-9** Subscription plans (name, monthly price, annual price, monthly booking quota, warning threshold) shall be stored as configurable records rather than hardcoded, so the platform team can rename a plan or adjust its price, quota, or warning threshold without a code deployment. Changing a plan's configuration shall apply to new or renewing subscriptions; the system shall preserve the price and quota an existing subscription was created under until that subscription renews or the owner explicitly changes plans, so a plan-level price or quota change does not silently alter what current subscribers are already paying for.
- **FR-ADM-10** The system shall allow a club owner's subscription (Growth or Unlimited) to be billed monthly or annually, at the owner's choice. Annual billing shall be discounted 10% versus twelve monthly payments at the plan's current monthly price. The Free plan has no billing cycle. The billing cycle governs only when a payment is due; quota metering runs on the Club's own rolling monthly period regardless (FR-ADM-4), so an annual subscriber is not metered annually.
- **FR-ADM-11** The system shall let the platform team maintain the platform's own bank account details used to collect subscription payments: bank name, account number, national ID (cédula/RIF), and holder name. The active account is the one shown to club owners on their payment screen (FR-ADM-12).
- **FR-ADM-12** When a subscription payment is due for a paid plan, the system shall present the club owner (on the plan/billing screen, which stays reachable even when restricted) the amount owed converted to VES at the current reference exchange rate (FR-PAY-9) together with the platform's Pago Móvil details (FR-ADM-11), and shall let the owner submit the transfer reference number. Submitting creates a pending subscription payment and emails both the owner and the platform team.
- **FR-ADM-13** The platform team shall verify each submitted reference and mark the subscription payment confirmed or rejected; the system shall email the owner the outcome. Only a confirmed payment counts as covering its billing period for the purposes of FR-ADM-7.
- **FR-ADM-14** The system shall let the platform team set a Club's directory-listed flag from the internal admin panel. The flag shall default to unlisted when a Club is created and shall NOT be settable by Club users (owner-side), so a demo or abusive Club cannot list itself. Only listed, active, unrestricted Clubs appear in the public club directory (FR-BOOK-14). The flag governs directory visibility only: an unlisted Club's own booking link remains fully reachable and bookable by its slug. Directory absence therefore has two independent causes that must not be conflated — not listed (a platform curation decision, this requirement) and restricted (a billing or quota condition, FR-BOOK-16) — and only the second also stops bookings.

## 3.9 Onboarding (ONB)

- **FR-ONB-1** The system shall guide a new user through account creation using a multi-step assisted form (club info including name and optional logo, first field, initial availability, pricing, accepted payment methods). Completing it creates a Club with the signing-in user as its founding Administrator (FR-ORG-1); inviting additional users and defining roles (§3.11) happens after onboarding, from the Users and roles screen.
- **FR-ONB-2** The system shall allow the club owner to complete onboarding with minimal required fields, deferring optional details (photos, amenities) to be added later.
- **FR-ONB-3** The system shall make the owner's public booking link (FR-BOOK-1) available automatically as soon as the first field is created; the link lists all of the owner's active fields.

## 3.10 Public Landing Page (LAND)

- **FR-LAND-1** The system shall provide a public marketing landing page describing the platform, the problem it solves, and its target audience (club owners).
- **FR-LAND-2** The landing page shall display the three subscription pricing tiers (Section 2.7) and their conditions.
- **FR-LAND-3** The landing page shall provide a call-to-action that lets an interested club owner start onboarding (FR-ONB-1) or contact the team directly.

## 3.11 Organization and Access Control (ORG)

- **FR-ORG-1** Account creation shall create a Club (the company behind the fields) together with the signing-in user as its founding Administrator: the system shall create the Club, a User record for the creator, a Membership linking them, and a built-in Administrador Role that grants every module and cannot be edited or deleted. The Club holds a display name (required) and a single optional logo.
- **FR-ORG-2** The system shall let a user with the settings module set and replace the Club's single logo. The logo is shown on the public booking link club landing view (FR-BOOK-3) and in the admin panel. It is optional; the Club functions fully without one.
- **FR-ORG-3** The system shall let a user with the user_management module invite a person to the Club by email address, selecting the Role they will receive. Inviting shall send that email a single-use, time-limited link (NFR-SEC-2) to set a password or sign in with Google; accepting the invite shall create the User (or link an existing one by email, per FR-AUTH-7) and create an active Membership with the assigned Role. At most one pending invitation may exist per email per Club; an Administrator may revoke a pending invitation.
- **FR-ORG-4** A User shall belong to a Club through a Membership that carries exactly one Role. A User may belong to more than one Club (each via its own Membership); the admin panel shall let such a user switch the active Club context. At most one Membership shall exist per User per Club.
- **FR-ORG-5** The system shall let a user with the user_management module create, rename, edit, and delete custom Roles within their Club. Each Role grants access to a configurable set of modules chosen from the module reference list (§6.1) via a checkbox matrix (allow/deny per module). The built-in Administrador Role grants all modules and shall not be editable or deletable.
- **FR-ORG-6** The system shall enforce Role permissions on every admin-panel action: a user shall be able to open and act within only the modules their Role grants, and the API shall authorize each request against the caller's effective module permissions for the active Club (NFR-SEC-5). billing and user_management are themselves modules and are gated the same way. The internal admin panel (§3.8) is a separate access space and is unaffected by Club Roles.
- **FR-ORG-7** The system shall let a user with the user_management module change a member's Role, suspend a member, or remove a member from the Club. A suspended or removed member shall lose admin-panel access to that Club immediately; their name remains on records they previously acted on (payment confirmations, cancellations, refunds).
- **FR-ORG-8** The system shall prevent a Club from locking itself out: the founding Administrator's Membership shall not be removable or strippable of the user_management module, and the system shall block removing, suspending, or downgrading the last active member holding the user_management module.
- **FR-ORG-9** The Club, not any individual user, shall own its fields, configurations, availability, bookings, payments, subscription, and usage metering (all reference club_id). User-attributable actions shall additionally record the acting user: payment confirmation (FR-PAY-3), cancellation (FR-CAN-3), and refund registration (FR-CAN-6).

---

# 4. Interface Requirements

This section describes user-facing screens at a level of detail intended to support UI mockups (e.g., in Claude Design) and frontend implementation.

## 4.1 User Interfaces

### 4.1.1 Admin Panel (Club owner) — Angular, desktop-first web, served on the club subdomain

- Served on the club subdomain (e.g., club.domain.com), separate from the public booking app (app subdomain) and the marketing site (www.domain.com/home).
- Login screen: "Continuar con Google" button as the primary, recommended action; email/password form as the secondary option, with a "forgot password" link (FR-AUTH-4).
- Dashboard/home: summary cards (bookings this month, revenue this month, occupancy rate), list of payments awaiting verification (Pago Móvil/Zelle references to confirm or reject, and Pay On Site payments to register).
- Onboarding wizard: club info → first field (name, photo, location) → Field Configuration (pricing, payment methods, refund policy) → availability rules → done (shows generated booking link).
- Calendar view: interactive weekly/monthly calendar per field, laid out on that field's own base-slot grid — which is generated per availability rule (FR-CAL-3) and may therefore change cadence across the day — plus any manually created slots. Drag-to-create slots, click to edit/delete (deletion refused on slots covered by an active booking, FR-CAL-4), visual distinction for booked / blackout / available slots, with a secondary indicator on booked slots whose payment is still unverified. A booking that spans several base slots (variable-duration config, FR-BOOK-15) is shown as one reservation across them. Clicking an open slot also offers "Create manual booking" for reservations taken by phone, WhatsApp, or in person, offering the same duration choice where the config is variable and including registering its payment. A manual booking that loses a race against a concurrent link booking is refused with the same clear message and refreshed calendar (FR-BOOK-18); the calendar shall not present stale availability as authoritative.
- Field management: list of the Club's fields, add/edit field (name, photos, Google Maps location, assigned Field Configuration), with a photo manager to add, reorder, remove, and set the primary photo (FR-CAL-18). Photos and location are optional but recommended.
- Availability rules: create/edit recurring availability per field (days, time window, base slot duration per rule, FR-CAL-3). Pricing is set on the Field Configuration, not here.
- Field Configuration management: list of reusable configurations, create/edit (sport type, base price, time-of-day rate bands, duration-based prices, payment methods, refund policy), and see which fields currently reference each one before saving a change.
- Bookings list: filterable/sortable table of bookings (date, player, field, status, payment method, payment status, source — Booking link, WhatsApp, Phone, Walk-in, Other), with actions to confirm/reject a payment, register a payment (any method, for link or manual bookings), cancel a booking, register a refund against a cancelled booking's payment (FR-CAN-6, showing the suggested eligibility hint), or add a manual booking.
- Plan & billing screen: current plan, usage this period, and — when a payment is due — the amount owed converted to VES, the platform's Pago Móvil details, and a field to submit the transfer reference (FR-ADM-12). This screen stays reachable even when the account is restricted.
- Analytics screen: charts/summary for bookings, revenue, occupancy; a settlement breakdown separating USD received (Zelle / on-site USD) from VES received, with VES split into USD-basis and EUR-basis intake (FR-ANA-6); export buttons (CSV, PDF).
- Club profile (settings): club name, single logo upload, contact details, the notification email that owner-facing messages are sent to, and the VES rate basis toggle (USD default / EUR) that sets how VES amounts owed are computed on this Club's bookings (FR-PAY-11).
- Users and roles screen (user_management module only): list of members with their role and status (active/suspended), an invite action (enter email, pick a role, send the Google/password link), and role management, create/edit/delete a role with a per-module checkbox matrix (calendar, bookings, payments, fields, field configurations, analytics, settings, billing, user management). The built-in Administrador role is shown as read-only (FR-ORG-3 to FR-ORG-8).
- Settings: account info, notification preferences, refund policy per Field Configuration.
- Module gating: which screens and actions above are visible and enabled depends on the signed-in user's role for the active Club (FR-ORG-6). The plan and billing screen requires the billing module; the Users and roles screen requires the user_management module.

### 4.1.2 Public Booking Link — mobile-responsive web

- Entry / routing: the public web app is served on the app subdomain (e.g., app.domain.com). Its root (no club identifier) shows the club directory (FR-BOOK-14); a club booking link is `app.domain.com/reservar/{club_slug}`, with an optional field deep-link at `app.domain.com/reservar/{club_slug}/{field_slug}`; an unknown slug returns to the directory. The marketing site is a separate surface at `www.domain.com/home` (Section 4.1.4), and the club owner dashboard is on the club subdomain (Section 4.1.1).
- Club directory view (root): public, no sign-in required; lists active Clubs (name, logo, location hint if set), each linking to its booking link. When the player is signed in, it also surfaces their active bookings across Clubs with a cancel action (FR-CAN-2). Empty state (no active Clubs) shows the PlaySpot logo and a short "nothing here yet" message.
- Club landing view: the Club's logo (if set) and name, and a list of their active fields (each with a cover photo and location preview if set). Public, no sign-in. If the player is signed in with an active session, this view also surfaces their active bookings (with a cancel action, per FR-CAN-2).
- Field view: field name, sport type, photo gallery (if any, primary first), an embedded Google Maps pin (if location set), and pricing summary. Gallery and map are omitted when unset. Public, no sign-in.
- Availability view: calendar/list of open slots for the selected field, clearly marking unavailable/booked slots. Public, no sign-in.
- Duration selection (conditional): when the field's configuration offers more than one duration (FR-CAL-19), after picking a start time the player chooses a duration, each shown with its price; only durations with a valid tiling run at that moment are offered (FR-BOOK-15). Availability shown here is a snapshot: if the run is taken before the player finishes, the attempt is refused at this step with a clear message and a refreshed view, never after payment details have been requested (FR-BOOK-18). Skipped entirely for flat configurations.
- Sign-in step (conditional, deferred): shown only when the player taps to book (or cancel) without an active session. "Continuar con Google" as the primary, recommended action; email/password register/login as the secondary option, with a "forgot password" link (FR-AUTH-4). Skipped entirely for players with a valid session (FR-AUTH-9).
- Profile capture (first time only): immediately after account creation, prompt for name and phone (FR-AUTH-10), name prefilled for Google sign-ups.
- Confirm-details screen: before finalizing a booking, name and phone are shown prefilled and editable; edits save to the profile (FR-BOOK-4). This is also how a returning player updates their name or phone.
- Payment instructions view (conditional): Pago Móvil or Zelle details plus reference-number input; for Pago Móvil the VES amount shown is computed at the Club's VES rate basis (USD or EUR, FR-PAY-11), while Zelle shows the USD amount unchanged; skipped entirely for Pay On Site.
- Confirmation screen: booking summary showing the booking as Active, plus its payment status ("payment pending verification" for Pago Móvil/Zelle, "pay at the field" for Pay On Site), with a reference the player can use later to cancel.
- My bookings / cancellation view: reachable from the club landing view when signed in, or by deep-link from the confirmation email; lists the player's active bookings and, on opening one, shows refund eligibility per the field's policy before cancelling (FR-CAN-2).

### 4.1.3 Internal Admin Panel — Angular, desktop-first web

- Login screen: internal/staff authentication (separate from club login).
- Owner accounts view: list of club accounts with status (active/deactivated), plan, billing cycle, current metering-period app-sourced booking count, and restriction reason(s) where any restriction is open — flagged prominently, since an open restriction now also means the Club's booking link is refusing new bookings (FR-BOOK-16); create and deactivate actions (FR-ADM-1, FR-ADM-2).
- Owner detail view: account info, fields summary, subscription payment history, and a "verify payment" action to confirm or reject owner-submitted references (FR-ADM-3, FR-ADM-13), plus a directory-listing toggle to list or unlist the Club in the public directory (FR-ADM-14; unlisted by default).
- Subscription payments queue: pending owner-submitted payments awaiting reference verification, with confirm/reject actions (FR-ADM-13).
- Platform bank account view: maintain the platform's Pago Móvil details (bank, account number, national ID, holder) shown to owners on their billing screen (FR-ADM-11).
- Restrictions view: two sections. (a) Restricted accounts: accounts with one or more open restrictions, each restriction shown with its reason — quota exceeded (FR-ADM-6) or payment overdue (FR-ADM-7) — and both listed when both apply (FR-ADM-8); a restriction is resolved by the owner upgrading, by the Club's metering period rolling over (both quota, FR-ADM-6), or by the platform team confirming the covering payment (overdue). Each restricted account is marked as having its booking link paused (FR-BOOK-16), and quota rows show the date their metering period next rolls, so the team can tell a self-healing pause from one needing action. (b) At risk: paid accounts whose billing period is past due but still inside the grace period, showing days remaining before the payment-overdue restriction triggers.
- Plan management view: list of configured subscription plans (name, monthly/annual price, booking quota, warning threshold) with edit access (FR-ADM-9).

### 4.1.4 Public Landing Page — marketing, mobile-responsive web

- Hero section: what the platform is, the problem it solves, and who it's for (club owners).
- Feature overview: calendar management, booking link, manual bookings, notifications.
- Pricing section: the three subscription tiers (Free, Growth, Unlimited) with their monthly and annual price and conditions.
- Call-to-action: "Start onboarding" (leads into FR-ONB-1) and a contact option for owners interested in the Unlimited plan or with custom questions.
- Routing note: the marketing landing page is served at `www.domain.com/home`, and `www.domain.com/` redirects to `/home`. The public booking app lives on the app subdomain (app.domain.com; club directory plus club booking links, Section 4.1.2) and the club owner dashboard on the club subdomain (Section 4.1.1); both are separate surfaces from this marketing page.

## 4.2 Hardware Interfaces

None beyond standard end-user devices (desktop/laptop for the admin panels, smartphone for the booking link). No specialized hardware is required.

## 4.3 Software Interfaces

| Interface | Purpose |
|---|---|
| Google Identity (OAuth 2.0 / OpenID Connect) | Club-user (owner-side) and player authentication via Google Sign-In (FR-AUTH-1, FR-AUTH-2, FR-AUTH-5). |
| Google Maps (embed / static map) | Rendering a field's location pin on the booking link when the owner has set coordinates (FR-BOOK-3). |
| Resend (transactional email API) | Sending booking confirmation and cancellation notifications, subscription-payment emails, and password reset links to club owners and players (FR-NOT-1 to FR-NOT-5, FR-ADM-12, FR-AUTH-4). |
| PostgreSQL | Primary relational data store, accessed by the Spring Boot API. |
| Spring Boot REST API | Backend service consumed by both Angular front ends (admin panel, booking link). |

## 4.4 Communication Interfaces

- All client-server communication over HTTPS.
- REST API using JSON payloads.
- Google Sign-In via standard OAuth 2.0 / OpenID Connect redirect flows over HTTPS.
- Emails delivered through Resend's API (all notifications, subscription-payment emails, and password resets).

---

# 5. Non-Functional Requirements

## 5.1 Performance

- **NFR-PERF-1** The booking link page shall load in under 3 seconds on a typical mobile connection in Venezuela.
- **NFR-PERF-2** The system shall support at least 50 concurrent booking submissions without data loss and without violating any of the availability invariants of §5.7. Concurrency here spans a booking's whole slot run, not a single slot: a booking may reserve several contiguous slots (FR-BOOK-15), and correctness is required for the run as a whole.

## 5.2 Availability

- **NFR-AVAIL-1** The system shall target 99.5% uptime, measured monthly.
- **NFR-AVAIL-2** Planned maintenance windows shall be scheduled outside peak booking hours where possible.
- **NFR-AVAIL-3** Since the platform runs on a self-managed VPS rather than a managed PaaS, the team shall be responsible for server monitoring, automated backups of the PostgreSQL database, and basic alerting on downtime.

## 5.3 Security

- **NFR-SEC-1** The system shall not store raw payment credentials; only payment reference numbers and confirmation status are recorded.
- **NFR-SEC-2** Password reset tokens and user-invitation tokens (FR-ORG-3) shall be single-use and time-limited. Admin-panel session tokens shall expire after a configurable inactivity period; booking-link player sessions follow the longer-lived policy of FR-AUTH-9 (default 30 days) and shall be revocable server-side.
- **NFR-SEC-3** All admin-panel and internal-admin-panel endpoints shall require authentication; internal admin actions shall require an elevated role.
- **NFR-SEC-4** Player personal data (name, phone number) shall be accessible only to the relevant Club (its authorized users) and internal admin staff.
- **NFR-SEC-5** The admin-panel API shall enforce Club-scoped, role-based access control: every request shall be authorized against the caller's active Membership and the module permissions of its Role (FR-ORG-6), and shall be scoped to that Club's data so a user of one Club cannot read or act on another's. Removing or suspending a member shall revoke access immediately.
- **NFR-SEC-6** Club-supplied URLs and content (logo, field photos, map coordinates) shall be treated as untrusted. The system shall not fetch a Club-supplied URL server-side on the basis of that input (to avoid server-side request forgery), rendering such assets only as client-side references, and shall validate and normalize them (scheme/host allow-list, size/type limits) before display. Combined with FR-ADM-14 (only platform-listed Clubs are publicly discoverable), this limits what unvetted Club content can be surfaced to the public.

## 5.4 Usability

- **NFR-USAB-1** The booking link flow shall be completable by a first-time player, including account creation via Google Sign-In, in under 3 minutes without instructions; a returning player with an active session (FR-AUTH-9) shall be able to complete a booking in under 1 minute.
- **NFR-USAB-2** All user-facing text shall be in Spanish (Phase 1).

## 5.5 Maintainability

- **NFR-MAINT-1** The sport-type field shall be modeled so that adding a new sport (e.g., tennis) requires configuration, not a schema migration.
- **NFR-MAINT-2** The codebase shall follow the shared OpenSpec structure so that features can be traced back to this SRS via derived specs.

## 5.6 Scalability

- **NFR-SCALE-1** The data model shall support multiple fields per owner and multiple owners without redesign, in anticipation of Phase 3 discovery features.

## 5.7 Data Integrity and Concurrency

A booking no longer occupies a single slot: it reserves a run of contiguous slots that must tile its duration exactly (FR-CAL-19). Availability is therefore a condition over several rows at once, evaluated against state that other users may be changing at the same moment. The requirements below state the correctness the system must deliver; how it is achieved is an implementation decision.

- **NFR-INTEG-1** The system shall validate a booking's slot run and reserve it as a single indivisible operation. The four tiling conditions of FR-CAL-19 shall hold at the moment the reservation is recorded, not merely at the moment availability was displayed or checked; if any slot in the run has ceased to be available in between, the entire booking shall fail and nothing shall be reserved. A booking shall never come into existence covering only part of its run.
- **NFR-INTEG-2** The system shall prevent a booking from being created concurrently with a change to the calendar state it depends on. Specifically, creating a booking, creating a blackout period (FR-CAL-16), deleting or moving a slot (FR-CAL-4), and editing a slot's price (FR-CAL-9) shall not be able to interleave in a way that leaves the data inconsistent — for example a slot that is simultaneously booked and blacked out, a booking whose slots no longer exist, or a booking whose frozen total (FR-BOOK-17) differs from the prices the player was shown. Where two such operations contend, one shall complete and the other shall be rejected with a clear reason; neither shall silently proceed on state the other has invalidated.
- **NFR-INTEG-3** The invariants below shall be enforced by database constraints, not by application logic alone. Application-level checks are permitted and encouraged for producing good error messages, but shall not be the only thing standing between concurrent operations and corrupt data, since two application checks can both pass before either writes:
  - at most one active booking per slot (FR-BOOK-8);
  - no two overlapping slots on the same field (FR-CAL-7);
  - at most one open account restriction per club per reason (FR-ADM-8);
  - at most one active subscription per club (§6.1, Subscription);
  - at most one refund per payment (FR-CAN-6);
  - at most one primary photo per field (FR-CAL-18);
  - at most one membership per user per club (FR-ORG-4), and at most one pending invitation per email per club (FR-ORG-3);
  - one booking usage period per club per period (FR-ADM-4).
- **NFR-INTEG-4** Constraints that cannot be expressed in the database shall be stated explicitly as application-enforced, so the gap is a known one rather than an oversight. In Phase 1 these are: the tiling-run test (FR-CAL-19), which depends on live slot state; non-overlapping availability rules (FR-CAL-20), whose day sets are stored as a bitmask; and the requirement that every slot a booking covers belongs to that booking's club and field (§6.1, Booking).
- **NFR-INTEG-5** A failed or rejected booking attempt shall leave no trace in the data: no orphaned booking row, no partially written slot reservation, no counter increment (FR-ADM-4), and no notification sent (FR-NOT-2). The quota counter shall increment only for bookings that actually became Active.

---

# 6. Data Requirements

## 6.1 High-Level Data Entities

The authoritative field-level schema is the ERD (`playspot-schema.mermaid`); it is the single source of truth for exact columns, types, keys, and nullability. This section describes only what each entity represents and the concepts worth understanding at the requirements level, in plain language, so the two artifacts don't have to be kept column-for-column in sync.

- **Club** — the company behind one or more fields (the tenant). Holds the display name, a single optional logo, the public slug for the booking link (FR-BOOK-1), the notification email for owner-facing messages, the subscription and usage metering, and the account status (active or deactivated only — "restricted" is not a stored status but a derived state, true exactly while any Account Restriction row is open, FR-ADM-1), and the day-of-month anchor of its rolling metering period (FR-ADM-4). A platform-only `listed` flag (default unlisted, FR-ADM-14) controls whether the Club appears in the public directory; being unlisted never affects the Club's own booking link, whereas being restricted does (FR-BOOK-16). Fields, configurations, bookings, payments, and subscriptions all belong to a Club (club_id), not to an individual user (FR-ORG-9).
- **User** — an owner-side login identity. Identified by email (globally unique among Club users); may sign in with Google, a password, or both (FR-AUTH-7). Carries name and phone and can belong to more than one Club through Memberships.
- **Membership** — links a User to a Club with exactly one Role (FR-ORG-4). Marks the founding Administrator (protected, FR-ORG-8) and carries a status (active/suspended). At most one Membership per User per Club.
- **Role** — a named, per-Club set of module permissions (FR-ORG-5). The built-in Administrador Role grants every module and cannot be edited or deleted; custom Roles grant any chosen subset.
- **Module** — the reference list of grantable admin-panel areas (calendar, bookings, payments, fields, field configurations, analytics, settings, billing, user management), so the permission matrix is data, not code. A Role Permission row grants one module to one Role.
- **Invitation** — a pending, tokenized email invite to join a Club with a given Role, accepted by setting a password or signing in with Google (FR-ORG-3). Single-use and time-limited.
- **Admin user** — a platform-team account with an elevated role, used for the internal admin panel.
- **Player** — an end user who books through a link. Identified by a required, unique email; may sign in with Google, a password, or both. A Player row always corresponds to a real account — there is no such thing as a Player without an email. Carries an unverified name and phone (FR-AUTH-10). A manual booking links to an existing player only when the owner supplies a matching email; it never creates a bare, credential-less player row, since the booking's contact snapshot covers that case (FR-BOOK-13).
- **Sport type** — reference list of sports (soccer, padel, extensible), so adding a sport is data, not a migration (NFR-MAINT-1).
- **Payment method** — reference list of the Phase 1 methods (Pago Móvil, Zelle, Pay On Site).
- **Field Configuration** — a reusable template shared across fields: sport type, default pricing (base price plus optional time-of-day rate bands (FR-CAL-8) and optional duration-based prices (FR-CAL-19)), accepted payment methods, and refund policy. The base slot duration is not part of the configuration; it is set per availability rule (FR-CAL-3), so fields and rules sharing a configuration can still run different cadences.
- **Field** — a physical field owned by a Club and governed by one Field Configuration. Has zero or more photos (Field Photo) and an optional Google Maps location, shown on the booking link when set (FR-BOOK-3). Its configuration must belong to the same Club (enforced in DDL).
- **Field Photo** — one image of a field, with a display order and an optional primary flag (the booking-link cover). A field may have several; the booking link shows them as a gallery (FR-BOOK-3, FR-CAL-18).
- **Availability rule** — a recurring schedule (days, time window, and its own base slot duration, default 90 minutes, FR-CAL-3) that generates base slots for a field. Scheduling only; pricing comes from the Field Configuration. Different rules on the same field, or on fields sharing a Field Configuration, may use different base durations, but two rules on the same field may not overlap in days, time window, and validity range at once (FR-CAL-20).
- **Blackout period** — a date/time range marking a field's slots unavailable. Creating one is blocked while any covered slot has an active booking (FR-CAL-16); deleting or shortening one returns the released slots to Available unless another blackout still covers them (FR-CAL-21).
- **Slot** — a base bookable interval (one grid unit) for a field, with its own price (editable while unbooked). A booking covers one or more contiguous slots (Booking Slot). Its status (available/booked/blackout) is a derived cache: Booked exactly when covered by one Active booking (enforced by a partial unique index on booking_slot), Blackout when it falls in a blackout period, otherwise Available; written only inside the transaction that books/cancels/blacks-out the slot. A slot covered by an active booking can be neither deleted nor moved in time (FR-CAL-4). Slots need not share a duration across a field: each availability rule sets its own, and manual slots set theirs individually, so the grid can change cadence through the day.
- **Booking** — a reservation of a contiguous run of slots on a field that tiles its chosen duration exactly (FR-CAL-19; see Booking Slot). Active at creation and released only by cancellation (FR-BOOK-7). Denormalizes the owning Club and Field so tenant scoping (NFR-SEC-5) and per-field queries do not have to traverse the slot join; the app enforces that every covered slot belongs to that Club and Field. Stores the booking's total USD price frozen at creation (FR-BOOK-17), which no later change to configuration pricing or slot prices may alter — this, not the current price of anything, is what revenue history reads. Carries a contact snapshot (name/phone/email) frozen at booking time so the record stays self-contained, a unique reference for self-service cancellation, and a source (booking link or a manual-entry origin). For manual entries the booking links to an existing Player when a matching email is supplied, and otherwise leaves player null and relies on the contact snapshot (FR-BOOK-13). Payment status is not stored on the booking; it is derived from the booking's Payment rows together with the chosen method, keeping the payment lifecycle fully independent of booking status.
- **Booking Slot** — links a Booking to each base slot it covers, with an active flag mirroring the booking so the one-active-booking-per-slot invariant (FR-BOOK-8) is enforced by a partial unique index. A booking on a flat configuration with no duration entries has one row; any other booking has one row per slot in its tiling run.
- **Payment** — money received for a booking, in any accepted method. Records the actual tender currency (VES or USD; owner-chosen for on-site), the USD amount and, for VES, the VES amount plus the exchange rate frozen at payment time, a reference number where applicable, and who confirmed it.
- **Exchange rate** — a captured VES-per-USD reference rate (BCV or manual) with the moment it was effective, so every VES amount can freeze the rate it used.
- **Refund** — a manual refund the owner registers against a specific payment: amount, date sent, optional note. At most one refund exists per payment (unique on payment); a partial refund is that single row with a smaller amount, not an instalment. Its existence is the record that a refund happened (FR-CAN-6).
- **Cancellation** — the booking-release event: who cancelled (player or club user — nothing cancels automatically, since bookings never expire), optional reason, when. It stores no refund verdict.
- **Subscription Plan** — a configurable plan (Free/Growth/Unlimited): name, monthly/annual price, booking quota, warning threshold. Editable by the platform team without a deployment (FR-ADM-9).
- **Subscription** — a club's history of plan enrollments; exactly one is active at a time (enforced by a partial unique index on club where the subscription is open). Its period is a billing period only: it governs when a payment is due and follows the chosen cycle (monthly or annual), and does not anchor quota metering, which runs on the Club's own period instead (FR-ADM-4). Freezes the price and quota it was created under so later plan-config changes don't affect existing subscribers.
- **Subscription payment** — an owner's payment for a subscription period, submitted through the in-platform Pago Móvil flow: the reference number, USD amount and expected VES at the captured rate, the period covered, verification outcome, and which admin confirmed it (FR-ADM-3, FR-ADM-11 to FR-ADM-13).
- **Platform bank account** — the platform's own Pago Móvil details (bank, account number, national ID, holder) shown to owners when a subscription payment is due (FR-ADM-11).
- **Account Restriction** — an open/resolved restriction on a Club, one row per reason (quota exceeded or payment overdue), with at most one open row per reason enforced by a partial unique index. While any row is open the Club's admin panel is limited to the plan/billing screen and its public booking link refuses new bookings (FR-BOOK-16). Each row records what resolved it: a confirmed subscription payment (overdue), a plan upgrade, or the opening of a new metering period (quota) (FR-ADM-6 to FR-ADM-8). This table, not a column on the Club, is the sole source of truth for whether a Club is restricted.
- **Booking Usage Period** — the per-club, per-period monotonic counter of Active app-sourced bookings backing quota metering; incremented on activation, never decremented within its period (FR-ADM-4), plus whether the warning email has fired (FR-ADM-5). Its period is a rolling month anchored to the Club, deliberately decoupled from the subscription: a plan change mid-period neither opens a new period nor resets the count, and an annual subscriber still meters monthly. Opening a new period resolves any open quota-exceeded restriction (FR-ADM-6).
- **Notification log** — a record of each email sent (type, recipient, status), email being the only Phase 1 channel.

## 6.2 Data Retention

Booking and payment-reference records shall be retained indefinitely for Phase 1 (subject to future policy). No automated data purging is required in Phase 1.

## 6.3 Currency and Exchange Rate Handling

USD is the reference currency for all field pricing (see FR-PAY-6). VES amounts are derivative: they exist only in the context of a specific payment, computed from the USD price and a reference exchange rate captured at that moment. The exchange rate is not a global mutable setting applied retroactively — each payment freezes its own rate and VES amount at confirmation time, so historical bookings and reports remain accurate even as the VES/USD rate moves. Wherever a VES payment is shown in the UI (booking detail, bookings list, analytics, CSV/PDF exports), both the VES amount and its USD-equivalent, plus the rate used, shall be visible.

A Club may elect a **VES rate basis** of EUR instead of the default USD (FR-PAY-11). Under the EUR basis, the VES amount owed on a VES-settled payment is derived from the VES-per-EUR rate rather than the VES-per-USD rate — the common Venezuelan practice of quoting the same numeric price in euros for local-currency settlement, to offset the official/market rate gap. EUR is never a tender and never a stored payment currency: it is only a conversion basis. Its effect is confined to the bolívar figure; the USD price (and therefore all USD-normalized revenue, analytics, and the booking's frozen total, FR-BOOK-17) is unchanged by the basis. Each VES payment freezes both its rate value and its base currency (USD or EUR), so a payment's VES amount is fully reconstructable and self-describing without consulting the Club's current setting. For accountability, VES intake is reported separately by basis (VES at USD basis vs. VES at EUR basis) alongside hard-currency USD intake (FR-ANA-6), while USD-normalized revenue stays basis-independent.

---

# 7. Constraints and Assumptions

## 7.1 Constraints

- Fixed technology stack: Angular, Spring Boot, PostgreSQL, self-managed VPS.
- No payment gateway integration in Phase 1.
- No native mobile app in Phase 1.
- Spanish-only UI in Phase 1.
- VES and USD only; no other currencies are tendered. (EUR may serve as an optional rate basis for computing VES amounts owed — FR-PAY-11 — but is never itself a payment currency.)

## 7.2 Assumptions

- Club owners will manually verify Pago Móvil/Zelle payments in a timely manner.
- Most club owners have a Google account and can use Google Sign-In; those who do not can register with email/password.
- Players are comfortable signing in with Google (or creating an email/password account) at the moment of booking, provided browsing remains open and the sign-in step is deferred to that moment.
- Demand and supply will grow enough in a given zone to justify Phase 3 discovery features.
- The subscription tier metric (Section 2.7) is confirmed to be total bookings per metering period made through the public booking link, counted per booking rather than per unique player; manually entered bookings do not count toward the limit.
- Accepted risk (FR-AUTH-6 lockout): a Club user or Player who signs in only with a password can have password login disabled by an attacker submitting five wrong passwords against their known email, forcing a password reset to recover. This is accepted deliberately — a fixed cooldown does not stop a sustained automated attempt, Google-linked accounts are unaffected, and the account holder is emailed the recovery path when the block fires (FR-AUTH-6).
- Accepted risk (restriction blast radius): pausing the booking link on an open restriction (FR-BOOK-16) means a billing or quota condition now costs the Club its public booking channel, not just its admin panel. This is accepted as the lesser harm — the alternative leaves players paying into a verification queue the Club is barred from processing — but it makes the FR-ADM-5 warning email and the FR-ADM-7 grace period load-bearing rather than courtesies, and it makes a Free-plan quota exhaustion a genuine outage for that Club until its metering period rolls (FR-ADM-6). Revisit if Free-tier churn at the quota boundary proves severe.
- Accepted risk: since link bookings become Active immediately (FR-BOOK-7) and never expire, a booking whose payment is never made holds its slot until the owner cancels it, and it still counts toward the tier quota (FR-ADM-4). Mitigations relied on in Phase 1: players must be signed in to book (FR-AUTH-5), owners can cancel no-pay bookings (FR-CAN-3), and login/booking abuse is rate-limited (FR-AUTH-6). If quota inflation from ghost bookings becomes a real problem, revisit before Phase 2. This risk is sharper now that exhausting a quota also pauses the booking link (FR-BOOK-16): ghost bookings no longer merely inflate a count, they can consume the quota that a Free-plan Club's public link depends on.

---

# 8. Traceability to Product Brief

This SRS operationalizes product-brief.md v1.8. Section 3 (Functional Requirements) corresponds to the brief's Phase 1 scope ("Herramienta de agenda + link de reserva web por cancha"). Note: the §3.11 organization/access-control model (Club + Users + Roles replacing the single club account) is an SRS-side expansion that runs ahead of the brief; the brief should be updated to describe the Club/team concept so the two stay aligned. Items explicitly out of scope in the brief (reviews/ratings, memberships/subscriptions for players, multi-currency beyond VES/USD, native mobile app, automated payment gateway, coach booking, tournaments, social/community features) are correspondingly absent from Section 3 and are called out in Section 7.1 as constraints.
